package facade;

public class TestResources {
    // Class with different utilities to help with the tests.
    public static final String EOL = System.lineSeparator();
}
